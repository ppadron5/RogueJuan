/**
 * The BaseCalculatorController class controls the Base Calculator (�)
 * @author Sebastian Klemkosky, Pedro Padron , Devin Silvas
 * UTSA CS 3443 - Group Project
 * Spring 2020
 */
package application.controller;

import java.io.IOException;

import application.model.BaseCalculator;
import application.model.BaseConversion;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

public class BaseCalculatorController {
	
	 	
	@FXML
	private TextField myNumber1TextField;
	
	@FXML
	private TextField myNumber2TextField;
	
	@FXML
	private TextField myBaseTextField;
	
	@FXML
	private TextArea myResultTextArea;
	
	@FXML
	private TextField myOperatorTextField;

	 
	
	
	
	/**
	 * Calculate method
	 * On Button Click this method takes in the infomation given by user and calls on the model to calculate
	 * @param event (MouseEvent)
	 */
	public void calculate(MouseEvent event) throws IOException {
		
		String stringNum1 = myNumber1TextField.getText();
		String stringNum2 = myNumber2TextField.getText();
		String stringOp = myOperatorTextField.getText();
		String stringBase = myBaseTextField.getText();
		
		
		
		
		if(stringOp.isEmpty() || stringOp == null) {
			myResultTextArea.setText("Error: Please enter a valid operator either + - * or /");		
		}
		else
		{	
			if(stringOp.charAt(0) == '+' || stringOp.charAt(0) == '-' || stringOp.charAt(0) == '*' || stringOp.charAt(0) == '/') {
				char op = stringOp.charAt(0);
				
				try
			    {
					
					
					
					int myBase = Integer.parseInt(stringBase.trim());
					
					
					BaseCalculator base = new BaseCalculator();
					
					
					String result = base.calculate(stringNum1,stringNum2,op,myBase);
					myResultTextArea.setText(result);
			      
			    }
			    catch (NumberFormatException nfe)
			    {
			      //System.out.println("NumberFormatException: " + nfe.getMessage());
			      myResultTextArea.setText("Error: Please enter a valid input");
			    }
				
			}
			else
			{
				myResultTextArea.setText("Error: Please enter a valid operator either + - * or /");		
			}
		}
		
		
	}
	
	
	/**
	 * Sets the Landing Scene
	 * @param event (MouseEvent)
	 */
	public void setLandingScene(MouseEvent event) throws IOException {
		
		Parent baseConverterRoot = FXMLLoader.load(getClass().getResource("/Landing.fxml"));
		Scene baseConverterScene = new Scene(baseConverterRoot);
		Stage baseConverterStage = (Stage)((Node)event.getSource()).getScene().getWindow();
		baseConverterStage.setScene(baseConverterScene);
		baseConverterStage.show();	
		

		
		//System.out.println("Hello World");
	}

}
