/**
 * The BaseConversion class represents Base Conversion (�)
 * @author Sebastian Klemkosky, Pedro Padron , Devin Silvas
 * UTSA CS 3443 - Group Project
 * Spring 2020
 */
package application.model;

public class BaseConversion {
	
	int toBase; //Integer of the Base to convert to
	int fromBase; //Integer of the Base to convert from
	int num; //Integer of the number to be converted
	
	
	/**
	 * Constructor
	 * @param toBase, fromBase, num (int)
	 */
	public BaseConversion(int toBase, int fromBase, int num) {
		this.fromBase = fromBase;
		this.toBase = toBase;
		this.num = num;
	}
	
	//Getters
	
	/**
	 * Returns the toBase
	 * @return int toBase
	 */
	public int getToBase() {
		return toBase;
	}
	
	/**
	 * Returns the fromBase
	 * @return int fromBase
	 */
	public int getFromBase() {
		return fromBase;
	}
	/**
	 * Returns the num
	 * @return int num
	 */
	public int getNum() {
		return num;
	}
	//Setters
	/**
	 * Sets the toBase
	 * @param toBase (int)
	 */
	public void setToBase(int toBase) {
		this.toBase = toBase;
	}
	/**
	 * Sets the fromBase
	 * @param fromBase (int)
	 */
	public void setfromBase(int fromBase) {
		this.fromBase = fromBase;
	}
	/**
	 * Sets the num
	 * @param num (int)
	 */
	public void setNum(int num) {
		this.num = num;
	}
	
	
	/**
	 * Base Convert function baseConvert
	 * @params toBase, fromBase (int)
	 * @param stringNum(String)
	 * This function takes a string of the number then converts it to a integer of the fromBase, then returns the integer converted to base toBase
	 */
	public String baseConvert(int toBase, int fromBase, String stringNum) {
		
		
		Integer result = Integer.valueOf(stringNum, fromBase); 
		//System.out.println(result);
		
		return Integer.toString( result , toBase );
		
		
	}
	/**
	 * toString method of BaseConversion class
	 */
	public String toString() {
		
		
		return "";
		
	}

}
