import java.util.*;
public class BaseCalc{

     public static void main(String []args){
        int x = 100110;
        String y = "23F";
        HexToBin(y);
     }

     public static int BinToDec(int num)        //Binary to Decimal conversion
     {
         int two;       //exp answer 
         int x = 0;     //return int
         int y;         //token
         int z = 0;     //exponent
         
          while(num > 0){
            y = num % 10;
            
            two = (int)Math.pow(2,z) * y;
            x = x + two;
               
            z = z + 1;
            num = num / 10;
            
          }
          
      System.out.println("The binary number expansion is " + x);
      return x;    
     }
     
     public static void BinToHex(int num)
     {
         int x = BinToDec(num);
         DecToHex(x);
     }
     
     public static int DecToBin(int num)        //Decimal to Binary conversion
     {
         int x = 0;     //return int
          
          ArrayList<Integer> rev = new ArrayList<Integer>();
          
          while(num > 0){
            rev.add(num % 2);
            num = num / 2;
          }

          for(int i = 0; i < rev.size(); i++) 
            {
                System.out.print(rev.get(rev.size() - i - 1) + "");
            }
          
      return x;    
     }
     
     public static void DecToHex(int num)
     {
//         int x = 0;     //return int
//         int y;         //token
//         int z = 0;     //exponent
          
          ArrayList<String> rev = new ArrayList<String>();
          
          while(num > 0){
            rev.add(String.valueOf(num % 16));
            num = num / 16;
          }

          for(int i = 0; i < rev.size(); i++) 
            {
                if(rev.get(rev.size() - i - 1).equals("10"))
                    rev.set(rev.size() - i - 1, "A");
                if(rev.get(rev.size() - i - 1).equals("11"))
                    rev.set(rev.size() - i - 1, "B");
                if(rev.get(rev.size() - i - 1).equals("12"))
                    rev.set(rev.size() - i - 1, "C");
                if(rev.get(rev.size() - i - 1).equals("13"))
                    rev.set(rev.size() - i - 1, "D");
                if(rev.get(rev.size() - i - 1).equals("14"))
                    rev.set(rev.size() - i - 1, "E");
                if(rev.get(rev.size() - i - 1).equals("15"))
                    rev.set(rev.size() - i - 1, "F");

                System.out.print(rev.get(rev.size() - i - 1) + "");
            }
           
    //   return x;
     }
     
     
     public static int HexToDec(String num)
     {
         int two;
         int x = 0;
         int i;
         
         ArrayList<Integer> rev = new ArrayList<Integer>();
         rev = addTo(num);
         
         for(i = 0; i < rev.size(); i++){
            two = (int)Math.pow(16,i) * rev.get(rev.size() - i - 1);
            x = x + two;
            
           
         }
        return x;  
     }
     
     public static void HexToBin(String num)
     {
         int x = HexToDec(num);
         DecToBin(x);
         
     }
     
     //WORKER METHODS
     
     public static ArrayList<Integer> addTo(String num)
     {
         ArrayList<Integer> rev = new ArrayList<Integer>();
         for(int i=0; i<=num.length()-1; i++) {
		    if(num.charAt(i) == '0')
		        rev.add(0);
            if(num.charAt(i) == '1')
		        rev.add(1);
            if(num.charAt(i) == '2')
		        rev.add(2);
		    if(num.charAt(i) == '3')
		        rev.add(3);
		    if(num.charAt(i) == '4')
		        rev.add(4);
		    if(num.charAt(i)== '5')
		        rev.add(5);
		    if(num.charAt(i)== '6')
		        rev.add(6);
		    if(num.charAt(i)== '7')
		        rev.add(7);
		    if(num.charAt(i)== '8')
		        rev.add(8); 
		    if(num.charAt(i)== '9')
		        rev.add(9);
		    if(num.charAt(i) == 'A')
		        rev.add(10);
		    if(num.charAt(i)== 'B')
		        rev.add(11);
		    if(num.charAt(i)== 'C')
		        rev.add(12);
		    if(num.charAt(i)== 'D')
		        rev.add(13);
		    if(num.charAt(i)== 'E')
		        rev.add(14); 
		    if(num.charAt(i)== 'F')
		        rev.add(15);     
	    }
	    
	    return rev;
     }
     
}